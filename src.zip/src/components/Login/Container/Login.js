import React from 'react';
import LoginUi from '../Ui/LoginUi';

const Login=()=>{
return <LoginUi/>
}

export default Login