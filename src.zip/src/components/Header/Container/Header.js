import React from 'react'
import HeaderUi from '../Ui/HeaderUi'

const HeaderCont=()=>{
    return(
        <HeaderUi/>
    )
}
export default HeaderCont