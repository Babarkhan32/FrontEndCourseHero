import React from 'react'
import ProfileUi from '../Ui/ProfileUi'

const Profile=()=>{
    return(
        <ProfileUi/>
    )
}
export default Profile